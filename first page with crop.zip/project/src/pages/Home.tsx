import React from 'react';
import { Plane as Plant, Cloud, DollarSign, Brush as Virus, Camera, FileText } from 'lucide-react';

function Home() {
  return (
    <>
      {/* Hero Section */}
      <div 
        className="relative h-[500px] bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative container mx-auto h-full flex items-center">
          <div className="text-white max-w-2xl px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Your Complete Farming Assistant
            </h1>
            <p className="text-xl mb-8">
              Get real-time information about crops, weather, market prices, and more to make informed farming decisions
            </p>
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2">
              <Camera className="h-5 w-5" />
              <span>Scan Crop Disease</span>
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto py-16 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Plant className="h-8 w-8 text-green-600" />}
            title="Crop Information"
            description="Detailed information about various crops, their growing seasons, and harvesting times."
          />
          <FeatureCard
            icon={<Cloud className="h-8 w-8 text-blue-600" />}
            title="Weather Updates"
            description="Real-time weather forecasts and agricultural weather advisories."
          />
          <FeatureCard
            icon={<DollarSign className="h-8 w-8 text-yellow-600" />}
            title="MSP & Market Rates"
            description="Current Minimum Support Prices and market rates for your crops."
          />
          <FeatureCard
            icon={<Virus className="h-8 w-8 text-red-600" />}
            title="Disease Detection"
            description="AI-powered crop disease detection and pesticide recommendations."
          />
          <FeatureCard
            icon={<FileText className="h-8 w-8 text-purple-600" />}
            title="Government Schemes"
            description="Latest agricultural schemes and policies from the government."
          />
          <FeatureCard
            icon={<Camera className="h-8 w-8 text-indigo-600" />}
            title="Image Analysis"
            description="Upload photos of your crops for instant disease detection."
          />
        </div>
      </div>
    </>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export default Home;