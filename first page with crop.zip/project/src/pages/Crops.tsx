import React, { useState } from 'react';
import { Search, ChevronDown, ChevronUp, Thermometer, Droplets, Sprout } from 'lucide-react';

interface Crop {
  id: number;
  name: string;
  image: string;
  description: string;
  sowingTime: string;
  harvestTime: string;
  waterRequirements: string;
  soilType: string;
  climate: string;
  fertilizers: string[];
  spacing: string;
  yield: string;
  varieties: string[];
  pests: string[];
  diseases: string[];
}

const crops: Crop[] = [
  {
    id: 1,
    name: 'Wheat',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80',
    description: 'Wheat is a cereal grain that is one of the world\'s most important food crops, providing about 20% of the calories consumed by humans globally.',
    sowingTime: 'October to December',
    harvestTime: 'March to April',
    waterRequirements: 'Moderate (450-650mm)',
    soilType: 'Well-drained loamy soil',
    climate: 'Cool climate (15-25°C)',
    fertilizers: ['NPK 20:20:0', 'Urea', 'DAP'],
    spacing: '20-22.5 cm row spacing',
    yield: '3.5-4.5 tonnes per hectare',
    varieties: ['HD 2967', 'PBW 343', 'WH 542', 'DBW 17'],
    pests: ['Aphids', 'Army Worm', 'Termites'],
    diseases: ['Yellow Rust', 'Powdery Mildew', 'Leaf Blight']
  },
  {
    id: 2,
    name: 'Rice',
    image: 'https://images.unsplash.com/photo-1536617621572-1d5f1e6269a0?auto=format&fit=crop&q=80',
    description: 'Rice is the staple food crop of more than half of the world\'s population. It\'s particularly important in Asia, where it provides 50-80% of people\'s energy intake.',
    sowingTime: 'June to July',
    harvestTime: 'November to December',
    waterRequirements: 'High (1000-1200mm)',
    soilType: 'Clay or clay loamy soil',
    climate: 'Hot and humid (22-32°C)',
    fertilizers: ['Urea', 'DAP', 'Potash', 'Zinc Sulphate'],
    spacing: '20 x 15 cm (row x plant)',
    yield: '5-6 tonnes per hectare',
    varieties: ['IR36', 'IR64', 'Swarna', 'MTU 7029'],
    pests: ['Stem Borer', 'Brown Plant Hopper', 'Leaf Folder'],
    diseases: ['Blast', 'Bacterial Leaf Blight', 'Sheath Blight']
  },
  {
    id: 3,
    name: 'Maize',
    image: 'https://images.unsplash.com/photo-1601472122408-25b092e61f0f?auto=format&fit=crop&q=80',
    description: 'Maize is a versatile crop used for food, feed, and industrial purposes. It\'s the most widely grown grain crop throughout the Americas.',
    sowingTime: 'June to July',
    harvestTime: 'September to October',
    waterRequirements: 'Moderate (500-800mm)',
    soilType: 'Well-drained loamy soil',
    climate: 'Warm (21-30°C)',
    fertilizers: ['NPK 15:15:15', 'Urea', 'DAP'],
    spacing: '60 x 20 cm (row x plant)',
    yield: '5.5-7.5 tonnes per hectare',
    varieties: ['DHM 117', 'Ganga 11', 'Deccan 103', 'Pro 311'],
    pests: ['Fall Armyworm', 'Stem Borer', 'Shoot Fly'],
    diseases: ['Leaf Blight', 'Rust', 'Downy Mildew']
  }
];

function Crops() {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCrop, setExpandedCrop] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'cultivation' | 'protection'>('overview');

  const filteredCrops = crops.filter(crop =>
    crop.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Crop Information</h1>
        <p className="text-gray-600">Comprehensive guide about different crops, their cultivation practices, and protection measures</p>
      </div>

      {/* Search Bar */}
      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="Search crops..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Crops Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {filteredCrops.map(crop => (
          <div key={crop.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img
              src={crop.image}
              alt={crop.name}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">{crop.name}</h2>
              
              {/* Tabs */}
              <div className="flex border-b mb-6">
                <button
                  className={`pb-2 px-4 ${activeTab === 'overview' ? 'border-b-2 border-green-500 text-green-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('overview')}
                >
                  Overview
                </button>
                <button
                  className={`pb-2 px-4 ${activeTab === 'cultivation' ? 'border-b-2 border-green-500 text-green-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('cultivation')}
                >
                  Cultivation
                </button>
                <button
                  className={`pb-2 px-4 ${activeTab === 'protection' ? 'border-b-2 border-green-500 text-green-600' : 'text-gray-500'}`}
                  onClick={() => setActiveTab('protection')}
                >
                  Protection
                </button>
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="space-y-4">
                  <p className="text-gray-600">{crop.description}</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Sprout className="text-green-500" />
                      <div>
                        <p className="text-sm font-medium">Sowing Time</p>
                        <p className="text-gray-600">{crop.sowingTime}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Thermometer className="text-red-500" />
                      <div>
                        <p className="text-sm font-medium">Climate</p>
                        <p className="text-gray-600">{crop.climate}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Droplets className="text-blue-500" />
                      <div>
                        <p className="text-sm font-medium">Water Needs</p>
                        <p className="text-gray-600">{crop.waterRequirements}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'cultivation' && (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Soil Requirements</h3>
                    <p className="text-gray-600">{crop.soilType}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Recommended Fertilizers</h3>
                    <ul className="list-disc list-inside text-gray-600">
                      {crop.fertilizers.map((fertilizer, index) => (
                        <li key={index}>{fertilizer}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Planting Details</h3>
                    <p className="text-gray-600">Spacing: {crop.spacing}</p>
                    <p className="text-gray-600">Expected Yield: {crop.yield}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Popular Varieties</h3>
                    <div className="flex flex-wrap gap-2">
                      {crop.varieties.map((variety, index) => (
                        <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm">
                          {variety}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'protection' && (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Common Pests</h3>
                    <ul className="list-disc list-inside text-gray-600">
                      {crop.pests.map((pest, index) => (
                        <li key={index}>{pest}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Common Diseases</h3>
                    <ul className="list-disc list-inside text-gray-600">
                      {crop.diseases.map((disease, index) => (
                        <li key={index}>{disease}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Crops;