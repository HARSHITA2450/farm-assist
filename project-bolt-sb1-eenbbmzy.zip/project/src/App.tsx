import React, { useState } from 'react';
import { Plane as Plant, Cloud, DollarSign, Brush as Virus, Camera, FileText, Menu, X } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-green-50">
      {/* Navigation */}
      <nav className="bg-green-700 text-white p-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Plant className="h-6 w-6" />
            <span className="text-xl font-bold">FarmAssist</span>
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">
            <NavLink icon={<Plant />} text="Crops" />
            <NavLink icon={<Cloud />} text="Weather" />
            <NavLink icon={<DollarSign />} text="MSP Rates" />
            <NavLink icon={<Virus />} text="Diseases" />
            <NavLink icon={<FileText />} text="Schemes" />
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-2">
            <MobileNavLink icon={<Plant />} text="Crops" />
            <MobileNavLink icon={<Cloud />} text="Weather" />
            <MobileNavLink icon={<DollarSign />} text="MSP Rates" />
            <MobileNavLink icon={<Virus />} text="Diseases" />
            <MobileNavLink icon={<FileText />} text="Schemes" />
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <div 
        className="relative h-[500px] bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative container mx-auto h-full flex items-center">
          <div className="text-white max-w-2xl px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Your Complete Farming Assistant
            </h1>
            <p className="text-xl mb-8">
              Get real-time information about crops, weather, market prices, and more to make informed farming decisions
            </p>
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2">
              <Camera className="h-5 w-5" />
              <span>Scan Crop Disease</span>
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto py-16 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Plant className="h-8 w-8 text-green-600" />}
            title="Crop Information"
            description="Detailed information about various crops, their growing seasons, and harvesting times."
          />
          <FeatureCard
            icon={<Cloud className="h-8 w-8 text-blue-600" />}
            title="Weather Updates"
            description="Real-time weather forecasts and agricultural weather advisories."
          />
          <FeatureCard
            icon={<DollarSign className="h-8 w-8 text-yellow-600" />}
            title="MSP & Market Rates"
            description="Current Minimum Support Prices and market rates for your crops."
          />
          <FeatureCard
            icon={<Virus className="h-8 w-8 text-red-600" />}
            title="Disease Detection"
            description="AI-powered crop disease detection and pesticide recommendations."
          />
          <FeatureCard
            icon={<FileText className="h-8 w-8 text-purple-600" />}
            title="Government Schemes"
            description="Latest agricultural schemes and policies from the government."
          />
          <FeatureCard
            icon={<Camera className="h-8 w-8 text-indigo-600" />}
            title="Image Analysis"
            description="Upload photos of your crops for instant disease detection."
          />
        </div>
      </div>
    </div>
  );
}

function NavLink({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <a href="#" className="flex items-center space-x-1 hover:text-green-200 transition-colors">
      {icon}
      <span>{text}</span>
    </a>
  );
}

function MobileNavLink({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <a href="#" className="flex items-center space-x-2 p-2 hover:bg-green-600 rounded transition-colors">
      {icon}
      <span>{text}</span>
    </a>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export default App;