import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Plane as Plant, Cloud, DollarSign, Brush as Virus, Camera, FileText, Menu, X } from 'lucide-react';
import Home from './pages/Home';
import Crops from './pages/Crops';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-green-50">
        {/* Navigation */}
        <nav className="bg-green-700 text-white p-4 shadow-lg">
          <div className="container mx-auto flex justify-between items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Plant className="h-6 w-6" />
              <span className="text-xl font-bold">FarmAssist</span>
            </Link>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>

            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-6">
              <NavLink to="/crops" icon={<Plant />} text="Crops" />
              <NavLink to="/weather" icon={<Cloud />} text="Weather" />
              <NavLink to="/msp" icon={<DollarSign />} text="MSP Rates" />
              <NavLink to="/diseases" icon={<Virus />} text="Diseases" />
              <NavLink to="/schemes" icon={<FileText />} text="Schemes" />
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 space-y-2">
              <MobileNavLink to="/crops" icon={<Plant />} text="Crops" />
              <MobileNavLink to="/weather" icon={<Cloud />} text="Weather" />
              <MobileNavLink to="/msp" icon={<DollarSign />} text="MSP Rates" />
              <MobileNavLink to="/diseases" icon={<Virus />} text="Diseases" />
              <MobileNavLink to="/schemes" icon={<FileText />} text="Schemes" />
            </div>
          )}
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/crops" element={<Crops />} />
        </Routes>
      </div>
    </Router>
  );
}

function NavLink({ icon, text, to }: { icon: React.ReactNode; text: string; to: string }) {
  return (
    <Link to={to} className="flex items-center space-x-1 hover:text-green-200 transition-colors">
      {icon}
      <span>{text}</span>
    </Link>
  );
}

function MobileNavLink({ icon, text, to }: { icon: React.ReactNode; text: string; to: string }) {
  return (
    <Link to={to} className="flex items-center space-x-2 p-2 hover:bg-green-600 rounded transition-colors">
      {icon}
      <span>{text}</span>
    </Link>
  );
}

export default App;