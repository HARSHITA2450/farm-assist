import React from 'react';
import { Info } from 'lucide-react';

function GovSchemes() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Government Schemes</h1>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {schemes.map((scheme) => (
          <div key={scheme.name} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 bg-blue-600 text-white">
              <h2 className="text-xl font-semibold">{scheme.name}</h2>
            </div>
            <div className="p-6">
              <p className="text-gray-600 mb-4">{scheme.description}</p>
              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <Info className="h-5 w-5 text-blue-500 mt-1" />
                  <div>
                    <h3 className="font-semibold">Benefits</h3>
                    <ul className="list-disc list-inside text-gray-600">
                      {scheme.benefits.map((benefit, index) => (
                        <li key={index}>{benefit}</li>
                      ))}
                    </ul>
                  </div>
                </div>
                <button className="mt-4 w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">
                  Apply Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const schemes = [
  {
    name: "PM-KISAN",
    description: "Direct income support to farmers for agricultural expenses",
    benefits: [
      "₹6000 annual financial benefit",
      "Direct bank transfer",
      "Support for farm inputs"
    ]
  },
  {
    name: "Kisan Credit Card",
    description: "Easy credit access for farmers",
    benefits: [
      "Flexible credit limit",
      "Low interest rates",
      "Insurance coverage"
    ]
  },
  {
    name: "Soil Health Card",
    description: "Detailed report of soil nutrient status",
    benefits: [
      "Free soil testing",
      "Crop-specific recommendations",
      "Improved soil health"
    ]
  }
];

export default GovSchemes;