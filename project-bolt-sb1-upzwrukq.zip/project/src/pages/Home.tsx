import React from 'react';
import { Link } from 'react-router-dom';
import { Plane as Plant, Cloud, TrendingUp, Camera, Building2 } from 'lucide-react';

function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Welcome to FarmAssist</h1>
        <p className="text-xl text-gray-600">Your complete farming companion</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Link to="/crop-info" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <Plant className="h-12 w-12 text-green-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Crop Information</h2>
          <p className="text-gray-600">Detailed guides on crop cultivation, care, and management</p>
        </Link>

        <Link to="/weather" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <Cloud className="h-12 w-12 text-blue-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Weather Updates</h2>
          <p className="text-gray-600">Real-time weather forecasts and agricultural alerts</p>
        </Link>

        <Link to="/market-rates" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <TrendingUp className="h-12 w-12 text-orange-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Market Rates & MSP</h2>
          <p className="text-gray-600">Current market prices and MSP for various crops</p>
        </Link>

        <Link to="/disease-detection" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <Camera className="h-12 w-12 text-purple-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Disease Detection</h2>
          <p className="text-gray-600">Scan and identify plant diseases with AI assistance</p>
        </Link>

        <Link to="/gov-schemes" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <Building2 className="h-12 w-12 text-red-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Government Schemes</h2>
          <p className="text-gray-600">Information about agricultural schemes and subsidies</p>
        </Link>

        <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
          <img 
            src="https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=400"
            alt="Farm landscape"
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
          <h2 className="text-xl font-semibold mb-2">Latest News</h2>
          <p className="text-gray-600">Stay updated with agricultural news and innovations</p>
        </div>
      </div>
    </div>
  );
}

export default Home;