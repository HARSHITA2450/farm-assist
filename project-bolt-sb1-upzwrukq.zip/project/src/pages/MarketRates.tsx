import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

function MarketRates() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Market Rates & MSP</h1>
      
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 bg-green-600 text-white">
            <h2 className="text-xl font-semibold">Current Market Prices</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {marketRates.map((crop) => (
                <div key={crop.name} className="flex items-center justify-between border-b pb-2">
                  <span className="font-medium">{crop.name}</span>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold">₹{crop.price}/quintal</span>
                    {crop.trend === 'up' ? (
                      <TrendingUp className="h-5 w-5 text-green-500" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 bg-blue-600 text-white">
            <h2 className="text-xl font-semibold">Minimum Support Price (MSP)</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {mspRates.map((crop) => (
                <div key={crop.name} className="flex items-center justify-between border-b pb-2">
                  <span className="font-medium">{crop.name}</span>
                  <span className="font-semibold">₹{crop.msp}/quintal</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const marketRates = [
  { name: "Wheat", price: 2015, trend: 'up' },
  { name: "Rice", price: 1960, trend: 'down' },
  { name: "Cotton", price: 6200, trend: 'up' },
  { name: "Soybean", price: 4150, trend: 'up' },
  { name: "Maize", price: 1850, trend: 'down' }
];

const mspRates = [
  { name: "Wheat", msp: 2015 },
  { name: "Rice", msp: 1960 },
  { name: "Cotton", msp: 5925 },
  { name: "Soybean", msp: 3950 },
  { name: "Maize", msp: 1870 }
];

export default MarketRates;