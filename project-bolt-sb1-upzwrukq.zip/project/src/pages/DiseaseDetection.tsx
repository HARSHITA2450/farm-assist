import React, { useState } from 'react';
import { Camera, Upload } from 'lucide-react';

function DiseaseDetection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Disease Detection</h1>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Upload Image</h2>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            {selectedImage ? (
              <img src={selectedImage} alt="Selected plant" className="max-w-full h-auto mb-4" />
            ) : (
              <div className="space-y-4">
                <Upload className="h-16 w-16 text-gray-400 mx-auto" />
                <p className="text-gray-600">Upload or drag and drop an image of the affected plant</p>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              id="image-upload"
            />
            <label
              htmlFor="image-upload"
              className="mt-4 inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 cursor-pointer"
            >
              <Camera className="h-5 w-5 mr-2" />
              Select Image
            </label>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
          {selectedImage ? (
            <div className="space-y-4">
              <div className="p-4 bg-yellow-50 rounded-lg">
                <h3 className="font-semibold text-yellow-800">Detected Disease</h3>
                <p className="text-yellow-600">Leaf Blight</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold">Recommended Treatment</h3>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Remove affected leaves</li>
                  <li>Apply fungicide treatment</li>
                  <li>Improve air circulation</li>
                  <li>Avoid overhead watering</li>
                </ul>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500">
              <p>Upload an image to see analysis results</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default DiseaseDetection;