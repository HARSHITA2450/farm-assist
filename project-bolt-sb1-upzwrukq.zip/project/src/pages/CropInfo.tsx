import React from 'react';

function CropInfo() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Crop Information</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {crops.map((crop) => (
          <div key={crop.name} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img src={crop.image} alt={crop.name} className="w-full h-48 object-cover" />
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-2">{crop.name}</h2>
              <p className="text-gray-600 mb-4">{crop.description}</p>
              <div className="space-y-2">
                <p><span className="font-semibold">Season:</span> {crop.season}</p>
                <p><span className="font-semibold">Water Needs:</span> {crop.waterNeeds}</p>
                <p><span className="font-semibold">Growth Period:</span> {crop.growthPeriod}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const crops = [
  {
    name: "Rice",
    image: "https://images.unsplash.com/photo-1536617621572-1d5f1e6269a0?auto=format&fit=crop&w=400",
    description: "Staple food crop grown in flooded fields",
    season: "Kharif",
    waterNeeds: "High",
    growthPeriod: "120-150 days"
  },
  {
    name: "Wheat",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=400",
    description: "Important cereal crop for food security",
    season: "Rabi",
    waterNeeds: "Moderate",
    growthPeriod: "120-150 days"
  },
  {
    name: "Cotton",
    image: "https://images.unsplash.com/photo-1594897030264-ab7d87efc473?auto=format&fit=crop&w=400",
    description: "Major commercial fiber crop",
    season: "Kharif",
    waterNeeds: "Moderate",
    growthPeriod: "150-180 days"
  }
];

export default CropInfo;