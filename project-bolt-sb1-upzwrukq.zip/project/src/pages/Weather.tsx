import React from 'react';
import { Cloud, Sun, Droplets, Wind } from 'lucide-react';

function Weather() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Weather Updates</h1>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Current Weather</h2>
          <div className="flex items-center space-x-4">
            <Sun className="h-16 w-16 text-yellow-500" />
            <div>
              <p className="text-4xl font-bold">28°C</p>
              <p className="text-gray-600">Sunny</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <Droplets className="h-8 w-8 text-blue-500 mx-auto" />
              <p className="mt-2">Humidity</p>
              <p className="font-semibold">65%</p>
            </div>
            <div className="text-center">
              <Wind className="h-8 w-8 text-gray-500 mx-auto" />
              <p className="mt-2">Wind</p>
              <p className="font-semibold">12 km/h</p>
            </div>
            <div className="text-center">
              <Cloud className="h-8 w-8 text-gray-400 mx-auto" />
              <p className="mt-2">Clouds</p>
              <p className="font-semibold">20%</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">5-Day Forecast</h2>
          <div className="space-y-4">
            {forecast.map((day) => (
              <div key={day.date} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                <span className="text-gray-600">{day.date}</span>
                <div className="flex items-center space-x-4">
                  {day.icon}
                  <span className="text-lg font-semibold">{day.temp}°C</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const forecast = [
  { date: "Tomorrow", temp: 29, icon: <Sun className="h-6 w-6 text-yellow-500" /> },
  { date: "Wed", temp: 27, icon: <Cloud className="h-6 w-6 text-gray-400" /> },
  { date: "Thu", temp: 26, icon: <Droplets className="h-6 w-6 text-blue-500" /> },
  { date: "Fri", temp: 28, icon: <Sun className="h-6 w-6 text-yellow-500" /> },
  { date: "Sat", temp: 30, icon: <Sun className="h-6 w-6 text-yellow-500" /> }
];

export default Weather;