import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import CropInfo from './pages/CropInfo';
import Weather from './pages/Weather';
import MarketRates from './pages/MarketRates';
import DiseaseDetection from './pages/DiseaseDetection';
import GovSchemes from './pages/GovSchemes';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/crop-info" element={<CropInfo />} />
          <Route path="/weather" element={<Weather />} />
          <Route path="/market-rates" element={<MarketRates />} />
          <Route path="/disease-detection" element={<DiseaseDetection />} />
          <Route path="/gov-schemes" element={<GovSchemes />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;